-- MySQL dump 10.13  Distrib 8.3.0, for Win64 (x86_64)
--
-- Host: localhost    Database: onlinebanking
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `account_id` int NOT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `user_nationalID` varchar(20) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_phoneNo` varchar(15) NOT NULL,
  `user_accountType` varchar(20) NOT NULL,
  `user_balance` decimal(10,2) NOT NULL,
  `currencyType` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  KEY `user_name` (`user_name`),
  CONSTRAINT `account_ibfk_1` FOREIGN KEY (`user_name`) REFERENCES `user` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (172811693,'ziad Elbahy','29903220104275','ziadelbahy@gmail.com','107333088','DEBIT',901.00,'EGP'),(211259223,'moustafa elsayed ahmed','29906270104698','socrat.sayed@yahoo.com','1554231524','DEBIT',200.00,'EGP'),(413924154,'moustafa elsayed ahmed','29906270104698','moustafaelsayed2427@gmail.com','1554231524','DOLLAR ACCOUNT',180.00,'USD'),(439650629,'AKARIM','123456789','AKARIM@GMAIL.COM','123456','DEBIT',3200.00,'EGP'),(511382051,'moustafa elsayed ahmed','29906270104698','moustafaelsayed2427@gmail.com','1554231524','DEBIT',740.00,'EGP'),(556453625,'youssef adel','29905220104532','youssefadel@gmail.com','1004333022','DEBIT',730.00,'EGP'),(862801735,'moustafa elsayed ahmed','29906270104698','socrat.sayed@yahoo.com','1554231523','CREDIT',17470.00,'EGP'),(907318122,'moustafa elsayed ahmed','29906270104698','m@mail.com','1554231524','DOLLAR ACCOUNT',100.00,'USD');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkstatement`
--

DROP TABLE IF EXISTS `checkstatement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checkstatement` (
  `statement_id` int NOT NULL AUTO_INCREMENT,
  `account_id` int NOT NULL,
  `transaction_type` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `currencyType` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`statement_id`),
  KEY `account_id` (`account_id`),
  CONSTRAINT `checkstatement_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkstatement`
--

LOCK TABLES `checkstatement` WRITE;
/*!40000 ALTER TABLE `checkstatement` DISABLE KEYS */;
INSERT INTO `checkstatement` VALUES (16,511382051,'deposit',900.00,'2024-02-01','EGP'),(17,511382051,'withdraw',300.00,'2024-02-01','EGP'),(18,556453625,'Transfer : -',33.00,'2024-02-01','EGP'),(19,556453625,'Transfer : -',33.00,'2024-02-01','EGP'),(20,511382051,'Transfer : +',33.00,'2024-02-01','EGP'),(21,556453625,'Transfer : -',4.00,'2024-02-01','EGP'),(22,511382051,'Transfer : +',4.00,'2024-02-01','EGP'),(23,862801735,'withdraw',3075.00,'2024-02-01','EGP'),(24,862801735,'withdraw',845.00,'2024-02-01','EGP'),(25,862801735,'withdraw',2460.00,'2024-02-01','EGP'),(26,862801735,'withdraw',3075.00,'2024-02-01','EGP'),(28,172811693,'withdraw',100.00,'2024-02-03','EGP'),(29,172811693,'deposit',99.00,'2024-02-03','EGP'),(30,862801735,'withdraw',3075.00,'2024-02-03','EGP'),(31,413924154,'withdraw',5.00,'2024-02-03','EGP'),(32,413924154,'withdraw',5.00,'2024-02-03','EGP'),(33,413924154,'withdraw',10.00,'2024-02-03','USD'),(34,413924154,'deposit',100.00,'2024-02-03','USD'),(35,413924154,'deposit',100.00,'2024-02-03','USD'),(36,413924154,'withdraw',100.00,'2024-02-03','USD'),(37,211259223,'Transfer : -',2.00,'2024-02-03','EGP'),(38,172811693,'Transfer : +',2.00,'2024-02-03','EGP'),(39,439650629,'deposit',3000.00,'2024-02-03','EGP'),(40,211259223,'deposit',2.00,'2024-02-03','EGP'),(41,511382051,'deposit',30.00,'2024-02-03','EGP'),(42,211259223,'deposit',100.00,'2024-02-03','EGP');
/*!40000 ALTER TABLE `checkstatement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_name` varchar(30) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  PRIMARY KEY (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('AKARIM','1234'),('Mohamed Hossam','777221'),('moustafa elsayed ahmed','12345'),('youssef adel','12345'),('Youssef Mekhdam','22222'),('ziad Elbahy','33333');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-03 19:08:19
