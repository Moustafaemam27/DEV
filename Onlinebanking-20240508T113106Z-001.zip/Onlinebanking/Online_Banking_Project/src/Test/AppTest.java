import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import java.sql.SQLException;

public class AppTest {
    private AAA TC1;
    private Operation TC2;
    private SoftAssert softAssert;

    @BeforeClass
    public void setUp() throws SQLException {
        TC1 = new AAA();
        softAssert = new SoftAssert();
        TC2 = new Operation();
    }

    @DataProvider(name = "creationOfAccount")
    public Object[][] createAccount() {
        return new Object[][] {
                {"29903220104275", "ziad Elbahy", "ziadelbahy@gmail.com", 107333088, "DEBIT", 900, "EGP"}
        };
    }

    @DataProvider(name="userCredentials")
    public Object[][] doSignUp(){
        return new Object[][] {
                {"ziad Elbahy","33333"},
                {"Mohamed Hossam","777221"}
        };}


    //SIGNUP METHOD TEST
    @Test(dataProvider = "userCredentials", priority = 1)
    public void testDoSignUp(String userName, String password) throws SQLException {
        TC1.doSignUp(userName, password);
        softAssert.assertTrue(TC1.doLogIn(userName, password), "Login failed after sign up");
        TC1.doLogout();
        softAssert.assertAll();
    }


    //CREATING ACCOUNT METHOD TEST
    @Test(dataProvider = "creationOfAccount", priority = 2)
    public void testCreationOfAccount(String user_nationalID, String accountName, String user_email, int user_phoneNo,
                                      String account_type, double balance, String currencyType) throws SQLException {
        TC1.createAccount( user_nationalID, accountName,  user_email,  user_phoneNo,
         account_type,  balance,  currencyType);
    }

   //TRANSACTION METHOD TEST
    @Test (priority = 3)
    public void testTransaction () throws SQLException {
        String account_id = "172811693";
        double withdrawlAmount = 100;
        double depositAmount = 99;
        TC2.withdraw(account_id,withdrawlAmount);
        TC2.deposit(account_id,depositAmount);
    }

    //SHOW ACCOUNTS METHOD TEST
    @Test(dataProvider = "userCredentials",priority = 4)
    public void testShowAccounts(String userName, String password) throws SQLException {
        if (userName.equals("ziad Elbahy")) {
            TC2.showAccounts(userName);
        }
    }

    //CHECK STATEMENT METHOD TEST
    @Test (priority = 5)
    public void testCheckStatement () throws SQLException {
        int account_id = 511382051;
        TC2.CHECKSTATEMENT(account_id);
    }

}