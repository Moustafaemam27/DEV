import java.sql.SQLException;
import java.util.*;

public class Access {
    private Scanner scanner = new Scanner(System.in);
    private AAA aaa ;
    private Operation operation ;
    private String currentUser = null,currencytype;
    String loginUsername;

    private Account account=new Account();
    double initialBalance=0;
    int phone_number=0;
    String email=null,account_type=null,nationalID=null;

    public Access() throws SQLException {
        aaa = new AAA();
        operation = new Operation();

    }

    public void displayHomepage() throws SQLException {
        System.out.println("Welcome to your bank!");

        while (true) {
            System.out.println("1. Already Have Account ?");
            System.out.println("2. New User ?");
            System.out.println("3. Exit ");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine() ;

            switch (choice) {
                case "1":
                    // Log in
                    System.out.print("Enter your username: ");
                    loginUsername = scanner.nextLine();
                    System.out.print("Enter your password: ");
                    String loginPassword = scanner.nextLine();
                    if (aaa.doLogIn(loginUsername, loginPassword)) {
                        currentUser = loginUsername;
                        displayUserMenu();
                    } else {
                        System.out.println("Invalid username or password. Please try again.");
                    }
                    break;
                case "2":
                    ///// Sign up
                    scanner.nextLine();
                    System.out.print("Enter your desired username: ");
                    String signupUsername = scanner.nextLine();
                    System.out.print("Enter your desired password: ");
                    String signupPassword = scanner.nextLine();
                    aaa.doSignUp(signupUsername, signupPassword);
                    break;

                case "3":
                    ///EXIT
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public void displayUserMenu() throws SQLException {
        while (true) {
            System.out.println("1. Create Account ");
            System.out.println("2. Transaction");
            System.out.println("3. Account Details");
            System.out.println("4. Show Accounts");
            System.out.println("5. Check statement");
            System.out.println("6. Logout");
            System.out.print("Enter your choice: ");
            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        // CREATE ACCOUNT
                        System.out.println("Your card is about to be created!");
                        System.out.println("Enter your national ID");
                        nationalID = scanner.next();
                        System.out.println("Enter your e-mail");
                        email = scanner.next();
                        System.out.println("Enter your phone number");
                        phone_number = scanner.nextInt();
                        System.out.println("Choose your card type\n 1-DEBIT \n 2-CREDIT  \n 3-PREPAID \n 4-DOLLAR ACCOUNT");
                        String cardtype = scanner.next();
                        switch (cardtype) {
                            case "1":
                                double amount=0;
                                while (amount<100){
                                    System.out.print("Enter initial balance: ");
                                    System.out.println(" * Note : Minimum Amount To Create Your Account is 100 EGP");
                                    amount = scanner.nextDouble();
                                    if(amount<100)
                                        System.out.println(" At least 100 EGP to Create your Account ");
                                    else {
                                        currencytype = "EGP";
                                        initialBalance=amount;
                                        account_type = "DEBIT";
                                    }
                                }
                                break;
                            case "2":
                                account_type = "CREDIT";
                                System.out.print("Enter Your Monthly Salary : ");
                                initialBalance = 3 * scanner.nextDouble();
                                currencytype = "EGP";
                                break;
                            case "3":
                                System.out.print("Enter initial balance: ");
                                System.out.println(" *Note : you don't have to have inital balance in PREPAID ");
                                initialBalance = scanner.nextDouble();
                                account_type = "PREPAID";
                                currencytype = "EGP";
                                break;
                            case "4":
                                amount = 0;
                                while (amount<10)
                                {
                                    System.out.println("Enter Initial Balance in $");
                                    System.out.println(" * Note : Minimum Amount To Create Your Account is 10$");
                                    amount = scanner.nextDouble();
                                    if (amount < 10)
                                        System.out.println(" can't procceed , minimum amount is 10$");
                                    else {
                                        initialBalance=amount;
                                        account_type = "DOLLAR ACCOUNT";
                                        currencytype = "USD";
                                    }
                                }
                                break;
                        }
                        aaa.createAccount(nationalID, loginUsername, email, phone_number, account_type, initialBalance, currencytype);
                        break;
                    case 2:
                        String transactionType = null;
                        System.out.println("1. Deposit");
                        System.out.println("2. Withdraw");
                        System.out.println("3. Transfer");
                        System.out.println("4. Change Currency");
                        System.out.println("5. go home page");
                        System.out.print("choose the transaction: ");
                        transactionType = scanner.next();
                        switch (transactionType) {
                            case "1":
                                // DEPOSIT
                                try {
                                    System.out.print("Enter account ID: ");
                                    String depositAccountId = scanner.next();
                                    System.out.print("Enter deposit amount: ");
                                    double depositAmount = scanner.nextDouble();
                                    operation.deposit(depositAccountId, depositAmount);
                                } catch (InputMismatchException e) {
                                    System.out.println("Invalid input. Please enter amount to deposit !.");
                                    scanner.nextLine();
                                }
                                break;
                            case "2":
                                // WITHDRAWAL
                                try {
                                    System.out.print("Enter account ID: ");
                                    String withdrawAccountId = scanner.next();
                                    System.out.print("Enter withdrawal amount: ");
                                    double withdrawAmount = scanner.nextDouble();
                                    operation.withdraw(withdrawAccountId, withdrawAmount);
                                } catch (InputMismatchException e) {
                                    System.out.println("Invalid input. Please enter amount to withdraw !.");
                                    scanner.nextLine();
                                }
                                break;
                            case "3":
                                // TRANSFER
                                System.out.print("Enter sender account ID: ");
                                String senderAccountId = scanner.next();
                                System.out.print("Enter recipient account ID: ");
                                String recipientAccountId = scanner.next();
                                System.out.print("Enter transfer amount: ");
                                double transferAmount = scanner.nextDouble();
                                operation.transfer(senderAccountId, recipientAccountId, transferAmount);
                                break;
                            case "4":
                                // CHANGE CURRENCY
                                System.out.println("USD Exchange Rate:");
                                System.out.println("Buy: 1 USD = 30.85 EGP");
                                System.out.println("Sell: 1 USD = 30.75 EGP");
                                System.out.println("\nEuro Exchange Rate:");
                                System.out.println("Buy: 1 Euro = 33.57 EGP");
                                System.out.println("Sell: 1 Euro = 33.47 EGP");
                                System.out.println("\nSR (Saudian Riyal) Exchange Rate:");
                                System.out.println("Buy: 1 SR = 8.45 EGP");
                                System.out.println("Sell: 1 SR = 8.35 EGP\n");
                                System.out.println("---------------------------------------------");
                                System.out.println("change to : \t 1-EGP \t 2-Euro \t 3-SR ");
                                int currency = scanner.nextInt();
                                System.out.println("enter your account ID ");
                                String accountID = scanner.next();
                                System.out.println("---*Note : Max Amount To Change Is 75 USD And It's Equivalence In Other Currencies ");
                                System.out.println("enter the amount you want to exchange In USD Currency");
                                double amount = scanner.nextDouble();
                                if (amount <= 75) {
                                    switch (currency) {
                                        case 1:
                                            currencytype = "EGP";
                                            operation.changeCurrency(accountID, amount, currencytype);
                                            break;
                                        case 2:
                                            currencytype = "Euro";
                                            operation.changeCurrency(accountID, amount, currencytype);
                                            break;
                                        case 3:
                                            currencytype = "SR";
                                            operation.changeCurrency(accountID, amount, currencytype);
                                            break;

                                        default:
                                            System.out.println("Invalid choice. Please try again.");
                                    }
                                } else System.out.println("CAN'T OCCUR ");
                                break;
                            case "5":
                                ///GO HOME PAGE
                                continue;
                        }
                        break;
                    case 3:
                        // SHOW ACCOUNT DETAILS
                        System.out.println("Enter the account ID you want to display");
                        try {
                            int accountID = scanner.nextInt();
                            operation.displayAccountDetails(accountID);
                        } catch (InputMismatchException e) {
                            System.out.println("Invalid input. Please enter a valid ID.");
                            scanner.nextLine();
                        }
                        break;
                    case 4:
                        ///SHOW ACCOUNTS
                        operation.showAccounts(loginUsername);
                        break;
                    case 5:
                        ///CHECK STATEMENT
                        System.out.println("enter the account ID");
                        int ID = scanner.nextInt();
                        operation.CHECKSTATEMENT(ID);
                        break;
                    case 6:
                        ///LOGOUT
                        aaa.doLogout();
                        currentUser = null;
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }catch (InputMismatchException e ){
                System.out.println("INVALID INPUT!");
                scanner.nextLine();
            }
        }
    }

}
