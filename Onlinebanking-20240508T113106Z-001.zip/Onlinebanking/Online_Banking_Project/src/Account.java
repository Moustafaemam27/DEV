public class Account {
    private long user_accountID = AAA.generateRandomId();
    private double balance;
    private String user_nationalID;
    //    private String currencyType;
    private int user_phoneNo;
    private String user_email;
    private String account_type;

    public Account(String user_nationalID,String user_email, int user_phoneNo,  String account_type,double balance) {
        this.user_accountID=AAA.generateRandomId();
        this.balance = balance;
        this.user_nationalID = user_nationalID;
        this.user_phoneNo = user_phoneNo;
        this.user_email = user_email;
        this.account_type = account_type;
    }

    public Account() {
        // Set a default value for user_accountID if needed
        this.user_accountID = AAA.generateRandomId();
    }

    public long getUser_accountID() {
        return user_accountID;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public double getBalance() {
        return balance;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }
}
