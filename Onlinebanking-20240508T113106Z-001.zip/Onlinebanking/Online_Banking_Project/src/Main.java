import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        Access object=new  Access();
        object.displayHomepage();
    }
}