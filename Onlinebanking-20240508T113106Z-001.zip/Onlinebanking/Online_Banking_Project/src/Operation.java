import java.sql.*;
import java.util.Date;

public class Operation implements Transaction {

    AAA aaa;

    private String checkstatment ;
    String updateQuery;
    String accountTypeQuery;
    Date currentDate ;

    java.sql.Date sqlDate;
    public Operation () throws SQLException {
        aaa=new AAA();
        checkstatment = "INSERT INTO checkstatement (account_id,transaction_type,amount,date,currencyType) VALUES (?,?,?,?,?)";
        currentDate = new Date();
        sqlDate = new java.sql.Date(currentDate.getTime());
        updateQuery = "UPDATE account SET user_balance = user_balance + ? WHERE account_id = ?";
        accountTypeQuery = "SELECT user_accountType FROM account WHERE account_id = ?";
    }

    @Override
    public void deposit(String accountId, double amount) throws SQLException {
        boolean accountExists = aaa.checkAccount(accountId);
        if (accountExists) {

            PreparedStatement preparedStatement9 = AAA.connection.prepareStatement(accountTypeQuery);
            preparedStatement9.setString(1, accountId);

            ResultSet resultSet = preparedStatement9.executeQuery();
            String accountType = null;

            if (resultSet.next()) {
                accountType = resultSet.getString("user_accountType");
            }

            resultSet.close();
            preparedStatement9.close();

            PreparedStatement updateStatement = AAA.connection.prepareStatement(updateQuery);
            PreparedStatement preparedStatement8 = AAA.connection.prepareStatement(checkstatment);
            preparedStatement8.setString(1, accountId);
            preparedStatement8.setString(2, "deposit");
            preparedStatement8.setDouble(3, amount);
            preparedStatement8.setDate(4, sqlDate);

            if (accountType.equals("DOLLAR ACCOUNT")) {
                preparedStatement8.setString(5, "USD");
                System.out.println(amount + " USD successfully deposited into account " + accountId);
            } else {
                preparedStatement8.setString(5, "EGP");
                System.out.println(amount + " EGP successfully deposited into account " + accountId);
            }

            updateStatement.setDouble(1, amount);
            updateStatement.setString(2, accountId);
            updateStatement.executeUpdate();
            preparedStatement8.execute();

            preparedStatement8.close();
            updateStatement.close();
        } else {
            System.out.println("Account " + accountId + " not found.");
        }
    }

    @Override
    public void withdraw(String account_id, double amount) throws SQLException {
        boolean accountExists = aaa.checkAccount(account_id);
        if (accountExists) {
            String updateQuery = "UPDATE account SET user_balance = user_balance - ? WHERE account_id = ?";
            String balanceQuery = "SELECT user_balance, user_accountType FROM account WHERE account_id = ?";
            double user_balance = 0;
            String accountType = null;

            PreparedStatement updateStatement = AAA.connection.prepareStatement(updateQuery);
            PreparedStatement balanceStatement = AAA.connection.prepareStatement(balanceQuery);
            balanceStatement.setString(1, account_id);
            ResultSet resultSet = balanceStatement.executeQuery();

            if (resultSet.next()) {
                user_balance = resultSet.getDouble("user_balance");
                accountType = resultSet.getString("user_accountType");
            }

            resultSet.close();
            balanceStatement.close();

            if (user_balance >= amount) {
                updateStatement.setDouble(1, amount);
                updateStatement.setString(2, account_id);

                PreparedStatement preparedStatement9 = AAA.connection.prepareStatement(checkstatment);
                preparedStatement9.setString(1, account_id);
                preparedStatement9.setString(2, "withdraw");
                preparedStatement9.setDouble(3, amount);
                preparedStatement9.setDate(4, sqlDate);

                if (accountType.equals("DOLLAR ACCOUNT")) {
                    preparedStatement9.setString(5, "USD");
                    System.out.println(amount + " $ successfully withdrawn from account " + account_id);
                } else {
                    preparedStatement9.setString(5, "EGP");
                    System.out.println(amount + " EGP successfully withdrawn from account " + account_id);
                }

                preparedStatement9.execute();
                preparedStatement9.close();
                updateStatement.executeUpdate();
                updateStatement.close();
            } else {
                System.out.println("Insufficient balance");
            }
        } else {
            System.out.println("Account " + account_id + " not found.");
        }
    }

    @Override
    public void transfer(String senderAccountId, String receiverAccountId, double amount) throws SQLException {
        boolean senderAccountExists = aaa.checkAccount(senderAccountId);
        boolean receiverAccountExists = aaa.checkAccount(receiverAccountId);

        if (senderAccountExists && receiverAccountExists) {

            String checkSenderBalanceQuery = "SELECT user_balance FROM account WHERE account_ID = ?";

            PreparedStatement sendercheckstatement = AAA.connection.prepareStatement(checkstatment);
            PreparedStatement recievercheckstatement = AAA.connection.prepareStatement(checkstatment);

            PreparedStatement checkSenderBalanceStatement = AAA.connection.prepareStatement(checkSenderBalanceQuery);
            checkSenderBalanceStatement.setString(1, senderAccountId);

            ResultSet senderBalanceResult = checkSenderBalanceStatement.executeQuery();
            if (senderBalanceResult.next()) {
                double senderBalance = senderBalanceResult.getDouble("user_balance");

                if (amount <= senderBalance) {
                    String updateSenderQuery = "UPDATE account SET user_balance = user_balance - ? WHERE account_id = ?";
                    PreparedStatement updateSenderStatement = AAA.connection.prepareStatement(updateSenderQuery);
                    updateSenderStatement.setDouble(1, amount);
                    updateSenderStatement.setString(2, senderAccountId);
                    sendercheckstatement.setString(1,senderAccountId);
                    sendercheckstatement.setString(2,"Transfer : -");
                    sendercheckstatement.setDouble(3,amount);
                    sendercheckstatement.setDate(4,sqlDate);
                    sendercheckstatement.setString(5,"EGP");
                    sendercheckstatement.execute();
                    updateSenderStatement.executeUpdate();
                    sendercheckstatement.close();
                    updateSenderStatement.close();

                    String updateReceiverQuery = "UPDATE account SET user_balance = user_balance + ? WHERE account_id = ?";
                    PreparedStatement updateReceiverStatement = AAA.connection.prepareStatement(updateReceiverQuery);
                    updateReceiverStatement.setDouble(1, amount);
                    updateReceiverStatement.setString(2, receiverAccountId);
                    recievercheckstatement.setString(1,receiverAccountId);
                    recievercheckstatement.setString(2,"Transfer : +");
                    recievercheckstatement.setDouble(3,amount);
                    recievercheckstatement.setDate(4,sqlDate);
                    recievercheckstatement.setString(5,"EGP");
                    updateReceiverStatement.executeUpdate();
                    recievercheckstatement.execute();
                    recievercheckstatement.close();
                    updateReceiverStatement.close();

                    System.out.println(amount + " EGP transferred from account " + senderAccountId + " to account " + receiverAccountId);
                } else {
                    System.out.println("Insufficient funds in account " + senderAccountId);
                }
            }
        } else {
            System.out.println("One or both accounts not found.");
        }
    }

    public void displayAccountDetails(int accountID) throws SQLException {
        String accountDetailsQuery = "SELECT * FROM account WHERE account_id = ?";
        PreparedStatement preparedStatement = AAA.connection.prepareStatement(accountDetailsQuery);
        preparedStatement.setInt(1, accountID);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            System.out.println("Account ID  : " + resultSet.getInt("account_id"));
            System.out.println("Account Name : " + resultSet.getString("user_name"));
            System.out.println("Account National ID : " + resultSet.getString("user_nationalID"));
            System.out.println("Account Type : " + resultSet.getString("user_accountType"));
            System.out.println("Email : " + resultSet.getString("user_email"));
            System.out.println("Phone number : " + resultSet.getString("user_phoneNo"));
            System.out.println("Current Balance : " + resultSet.getDouble("user_balance"));
            resultSet.close();
        } else {
            System.out.println("Account not found.");
        }
    }

    public void showAccounts(String username) throws SQLException {
        String query = "SELECT account_id, user_accountType FROM account WHERE user_name = ?";
        PreparedStatement preparedStatement = AAA.connection.prepareStatement(query);
        preparedStatement.setString(1, username);
        ResultSet resultSet = preparedStatement.executeQuery();
        boolean accountsFound = false;
        while (resultSet.next()) {
            int accountId = resultSet.getInt("account_id");
            String userAccountType = resultSet.getString("user_accountType");
            System.out.println("Account ID: " + accountId);
            System.out.println("Account Type: " + userAccountType);
            System.out.println("-----------------------");
            accountsFound = true;
        }
        if (!accountsFound) {
            System.out.println("NO ACCOUNTS FOUND !");
        }
    }

    public void CHECKSTATEMENT (int account_id) throws SQLException {
        String checkstatement = "select * from checkstatement where account_id = ? ";
        PreparedStatement preparedStatement = AAA.connection.prepareStatement(checkstatement);
        preparedStatement.setInt(1,account_id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            int accountId = resultSet.getInt("account_id");
            int statementID = resultSet.getInt("statement_id");
            String transactionType = resultSet.getString("transaction_type");
            double amount = resultSet.getDouble("amount");
            Timestamp date = resultSet.getTimestamp("date");

            System.out.println("Statment ID: "+statementID +" Account ID: " + accountId + " Transaction type : "+transactionType + " Amount :"+amount + " DATE : "+ date);
            System.out.println("-----------------------");
        }

    }

    public void changeCurrency (String account_id , double amount , String currencyType) throws SQLException {
        double  usdToEgp , usdToeuro , usdToSR;
        String accountType = " SELECT user_accountType FROM account WHERE account_id = ? ";
        PreparedStatement preparedStatement = AAA.connection.prepareStatement(accountType);
        preparedStatement.setString(1, account_id);
        ResultSet resultSet = preparedStatement.executeQuery();

        if((resultSet.next() && resultSet.getString("user_accountType").equals("DOLLAR ACCOUNT"))) {
            switch (currencyType) {
                case "EGP":
                    usdToEgp = amount * 30.85;
                    withdraw(account_id, amount);
                    System.out.println("Succesfully Changed " + amount + " USD To " + usdToEgp + " EGP");
                    break;
                case "EURO":
                    usdToeuro = amount * 0.93;
                    withdraw(account_id, amount);
                    System.out.println("Succesfully Changed " + amount + " USD To " + usdToeuro + " €");
                    break;
                case "SR":
                    usdToSR = amount * 3.75;
                    withdraw(account_id, amount);
                    System.out.println("Succesfully Changed " + amount + " USD To " + usdToSR + "   SR");
                    break;
                default:
                    System.out.println(" Invalid Choice ");
            }
        }
        else System.out.println("YOU MUST HAVE A DOLLAR ACCOUNT TO EXCHANGE !\n ANY OTHER TYPE IS NOT ACCEPTED");
    }

}


