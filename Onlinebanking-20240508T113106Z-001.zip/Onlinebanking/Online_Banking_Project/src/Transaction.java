import java.sql.SQLException;

public abstract interface Transaction {

    void deposit(String accountId, double amount) throws SQLException;

    abstract public void withdraw(String accountId, double amount) throws SQLException;
    abstract public void transfer(String senderAccountId , String recieverAccountId , double amount) throws SQLException;

}
