import java.sql.*;
import java.util.Random;

public class AAA {
    String url = "jdbc:mysql://localhost:3306/onlinebanking";
    String username = "root";
    String password = "12345";
    static Connection connection;

    private static String inserttoQuery = "INSERT INTO account (account_id,user_name,user_nationalID,user_email,user_phoneNo,user_accountType,user_balance,currencyType) VALUES (?,?,?,?,?,?,?,?)";
    private String selecttoQuery = "SELECT * FROM account WHERE account_id = ?";

    String insertQuery = "INSERT INTO User (user_name, user_password) VALUES (?, ?)";
    PreparedStatement preparedStatement;

    private boolean loggedIn = false;
    private User currentUser = new User();
    private Account newaccount = new Account();
    private int loginTrials = 3;

    public AAA() throws SQLException {
        connection = DriverManager.getConnection(url, username, password);
        preparedStatement = connection.prepareStatement(insertQuery);

    }

    public void doSignUp(String userName, String password) throws SQLException {
        if (loggedIn) {
            System.out.println("You're already logged in. Please log out first.");
            return;
        }

        String selectQuery = "SELECT * FROM User WHERE user_name = ?";
        PreparedStatement checkUserExistsStatement = connection.prepareStatement(selectQuery);
        checkUserExistsStatement.setString(1, userName);

        ResultSet resultSet = checkUserExistsStatement.executeQuery();
        if (resultSet.next()) {
            System.out.println("This username already exists! Please choose another one.");
            checkUserExistsStatement.close();
            resultSet.close();
            return;
        }

        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, password);
        preparedStatement.executeUpdate();
        preparedStatement.clearParameters();
        checkUserExistsStatement.close();
        resultSet.close();
        System.out.println("You've signed up successfully! Now you can log in to the program.");
    }

    public boolean doLogIn(String userName, String password) throws SQLException {
        String selectQuery = "SELECT * FROM User WHERE user_name = ? AND user_password = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);

        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, password);

        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            currentUser.setPassword(resultSet.getString("user_password"));
            loggedIn = true;
            System.out.println("Login successful! Welcome, " + userName);

            preparedStatement.close();
            resultSet.close();
            return true;
        } else {
            loginTrials--;

            if (loginTrials == 0) {
                System.out.println("You have exceeded the number of login trials. Exiting...");
                System.exit(1);
            } else {
                System.out.println("Invalid username or password!");
            }
        }
        preparedStatement.close();
        resultSet.close();
        return false;
    }


    public void doLogout() {
        if (!loggedIn) {
            System.out.println("You're not logged in.");
            return;
        }
        loggedIn = false;
        System.out.println("Logged out. Goodbye!");
    }

    public void createAccount(String user_nationalID,String accountName ,String user_email, int user_phoneNo, String account_type, double balance , String currencyType) throws SQLException {
        Account account = new Account(user_nationalID,user_email, user_phoneNo,account_type,balance);
        PreparedStatement preparedStatement = connection.prepareStatement(inserttoQuery);
        preparedStatement.setLong(1,account.getUser_accountID());
        preparedStatement.setString(2,accountName);
        preparedStatement.setString(3, user_nationalID);
        preparedStatement.setString(4,user_email);
        preparedStatement.setInt(5,user_phoneNo);
        preparedStatement.setString(6,account_type);
        preparedStatement.setDouble(7,balance);
        preparedStatement.setString(8,currencyType);
        preparedStatement.executeUpdate();
        preparedStatement.close();


        System.out.println("Account " + account.getUser_accountID() + " created with initial balance " + balance + currencyType);
    }

    protected boolean checkAccount(String account_id) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(selecttoQuery);
        preparedStatement.setString(1, account_id);
        ResultSet resultSet = preparedStatement.executeQuery();
        if(resultSet.next()){
            resultSet.close();
            preparedStatement.close();
            return true;
        }
        else{
            resultSet.close();
            preparedStatement.close();
            return false;
        }
    }

    public static long generateRandomId() {
        final String CHARACTERS = "0123456789";
        final int ID_LENGTH = 9;
        final Random random = new Random();
        StringBuilder sb = new StringBuilder(ID_LENGTH);
        for (int i = 0; i < ID_LENGTH; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            char randomChar = CHARACTERS.charAt(randomIndex);
            sb.append(randomChar);
        }
        return  Long.parseLong(sb.toString());
    }
}
